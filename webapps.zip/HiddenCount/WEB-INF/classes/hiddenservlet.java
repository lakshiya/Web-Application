import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class hiddenservlet extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse response) throws IOException,ServletException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int hit;
		String hitcount = req.getParameter("hitcount");
		try{
			if(hitcount.equals("hitstring"))
			{
				out.println("Welcome user");
				hit = 1;
				hitcount = String.valueOf(hit);
			}	
			else
			{
				int val = Integer.parseInt(hitcount);
				out.println("Welcome back user");
				hit = val +1;
				hitcount = String.valueOf(hit);
			}	
		out.println("<br>");
		out.println("Count is "+hitcount);
		out.println("<html>");
		out.println("<form method='get' action='s1'>");
		out.println("<input type='hidden' name='hitcount' value='"+hitcount+"'>");
		out.println("<input type='submit' value='Visit Again'>");
		out.println("</form></html>");
		}
		catch(Exception e)
		{
			out.println("error");
		}
		out.close();
	}
}	
