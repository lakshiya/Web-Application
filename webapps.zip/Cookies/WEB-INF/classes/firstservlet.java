import java.util.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class firstservlet extends HttpServlet{
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		try{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("uname");
		out.println("Name Entered is "+name);
		Cookie ck = new Cookie("Name",name);
		response.addCookie(ck);
		out.println("<html>");
		out.println("<form method='POST' action='secondservlet'>");
		out.println("<input type='submit' value='submit'>");
		out.println("</form></html>");
		out.close();
	}
	catch(Exception e){System.out.println(e);}
		
	}
}	
