import java.util.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class secondservlet extends HttpServlet{
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		try{
		response.setContentType("text/html");
		PrintWriter pwr = response.getWriter();
		String name = request.getParameter("uname");
		pwr.println("Name Entered is "+name);
		Cookie cookie = null;
		Cookie[] cookies = request.getCookies();
		for (int i = 0; i < cookies.length; i++){
            cookie = cookies[i];
            pwr.print("Name : " + cookie.getName( ) + ",  ");
            pwr.print("Value: " + cookie.getValue( )+" <br/>");
		}
		pwr.close();
	}
	catch(Exception e){System.out.println(e);}
		
	}
}	
