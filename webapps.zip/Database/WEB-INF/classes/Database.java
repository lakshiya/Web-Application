import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Database extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		final String jdbc_driver = "com.mysql.jdbc.driver";
		final String db_url = "jdbc:mysql://localhost:3306/IP";
		String user = "root";
		String pass = "vogue@pl";
		Connection con = null;
			Statement stmt = null;
		out.println("Database Result :");
		try{
			Class.forName("com.mysql.jdbc.Driver");
			
			con = DriverManager.getConnection(db_url,user,pass);
			stmt = con.createStatement();
			String sql = "select * from test";
			out.println(sql);
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				String name = rs.getString("uname");
				String password = rs.getString("password");
				
				out.println("Name : "+name);
				out.println("<br>");
				out.println("Password : "+password);
			}
			rs.close();
			stmt.close();
			con.close();
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			try{
			if(stmt!=null)
				stmt.close();
			}
			catch(SQLException se)
			{}
			try{
				if(con!=null)
				con.close();
			}
			catch(SQLException se)
			{se.printStackTrace();}
		}
	}
}	