package loginDAO;

import Bean.User;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class loginDAO{
	public int authenticate(User u){
		String name = u.getName();
		String pass = u.getPass();

		final String JDBC_DRIVER="com.mysql.jdbc.Driver";
		final String DB_URL="jdbc:mysql://localhost:3306/IP";

		final String USER="root";
		final String PASS="vogue@pl";

		Connection conn=null;
		Statement stmt=null;

		String title="Result";

		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(DB_URL,USER,PASS);
			stmt=conn.createStatement();

			String sql;
			sql = "SELECT * FROM test";
			ResultSet rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				
				String username=rs.getString("uname");
				String userpass=rs.getString("password");
					
				if(name.equals(username))
				{
					if(pass.equals(userpass))
					return 2;	
				
					else
						return 1;
				}	
			}
			rs.close();
			stmt.close();
			conn.close();
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(stmt!=null)
					stmt.close();
			}catch(SQLException se2){
			}
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se3){
				se3.printStackTrace();
			}
		}
		return 0;
	}
}