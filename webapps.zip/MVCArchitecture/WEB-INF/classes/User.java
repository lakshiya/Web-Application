package Bean;

public class User{
	String name,pass;
	
	public void setName(String n){
		name=n;
	}

	public void setPass(String p){
		pass=p;
	}

	public String getName(){
		return name;
	}

	public String getPass(){
		return pass;
	}
}