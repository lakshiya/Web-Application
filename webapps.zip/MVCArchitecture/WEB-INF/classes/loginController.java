import Bean.User;
import loginDAO.loginDAO;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class loginController extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String name = request.getParameter("uname");
		String pass = request.getParameter("upass");

		User u = new User();
		u.setName(name);
		u.setPass(pass);

		loginDAO d = new loginDAO();

		int f;
		f = d.authenticate(u);
		
		if(f==2)
		{
			request.getRequestDispatcher("success.jsp").forward(request,response);
		}
		if(f==1)
		{
			request.getRequestDispatcher("retry.jsp").forward(request,response);
		}
		else{
			request.getRequestDispatcher("failure.jsp").forward(request,response);
		}
	}
}